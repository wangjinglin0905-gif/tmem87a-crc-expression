# Additional file 1 Cohort flow and established results

## Single-cell discovery cohorts

| Cohort | Processed cells | Patients | Patients with both tissue types | 20-cell pairs | 50-cell pairs | Evaluable tumour shares |
|---|---:|---:|---:|---:|---:|---:|
| GSE132465 | 63,689 | 23 | 10 | 8 | 7 | 23 |
| GSE178341 | 370,115 | 62 | 36 | 36 | 35 | 61 |
| GSE166555 | 68,702 | 12 | 11 | 11 | 11 | 11 |

GSE132465 SMC05 had 13 tumour epithelial cells and SMC08 had 18 normal epithelial cells. GSE178341 preparation sensitivity retained 60 tumour donors with available unsorted tumour cells, and 32 tumour–adjacent pairs qualified in the unsorted-only 20-cell analysis. Share eligibility required all three mapped compartments and a nonzero gene denominator. P026 is share-eligible in GSE166555 and has only tumour tissue. P020 is epithelial-pair-eligible and its tumour lacked mapped stromal cells. See Additional file 2 for donor-level summaries.

`epithelial*`, `processing*` and `singlecell_view_counts.tsv` hold the discovery effect estimates, interval, patient-paired values, thresholds, preparation sensitivities and denominators. GSE132465 uses the deposited log(TPM + 1) matrix transformed back to the source normalized scale. GSE178341 uses CP10K from the deposited UMI library. Source releases are [GSE132465](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE132465) and [GSE178341](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE178341).

## Bulk expression and survival

`S08_expression_all_designs.tsv` contains the 50/98/30 paired contrasts and ancillary comparisons. TCGA COAD/READ used the paired harmonized TCGA expression matrix on log₂(TPM + 1) scale. GSE44076 used processed log₂ HG-U219 values with 98 tumour–adjacent pairs, with the 50 healthy specimens only used in a separate comparison. GSE74602 used deposited processed gene-centred values and 30 paired Illumina arrays. Microarray probes mapped to gene symbols. The probe with the largest median absolute deviation among tumour samples was selected. Paired effects averaged the tumour-minus-reference differences. The bootstrap sampled patients and Wilcoxon P values were adjusted by BH within each six-target bulk cohort family. [TCGA project publication](https://doi.org/10.1038/nature11252) · [GSE44076](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE44076) · [GSE74602](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE74602)

`S12a_survival_models.tsv`, `S12b_survival_PH.tsv` and `S12c_numbers_at_risk.tsv` provide the exploratory model outputs, diagnostics and risk tables with the original expression-tertile contrast. The analysis required positive follow-up and interpretable binary events. Low, middle and high expression tertiles were determined within cohort and preserved in complete-case subsets. Reported HRs compare high versus low. Cox models use Efron ties. TCGA adjusted for MSI and AJCC stage I–IV factor, combining the lettered substages within stage, and was repeated with stage-specific baseline hazards after the PH diagnostic. GSE39582 adjusted for available MMR status. Unadjusted analyses on all eligible and complete cases quantify the influence of missingness. No covariates were imputed. [GSE39582](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE39582)

## Protein and staining

The `cptac*` files provide the observed relative TMT differences, tumour RNA correlations, input file hashes and reconciliation against the separately deposited paired-difference matrix. Matched tissue IDs were intersected by explicit tumour–normal mapping after removal of the normal suffix. There were 96 matched patient IDs, with 96 paired TMEM87A and 80 paired TMEM63A values. Tumour RNA–protein correlations used 96 and 90 available pairs of assays, respectively. `cptac_patient_targets.tsv` omits sample identifiers and retains the numeric values used by the reproduction script. The source is the [LinkedOmics CPTAC-COAD catalog](https://www.linkedomics.org/data_download/CPTAC-COAD/), with PNNL TMT proteome matrices dated 03/01/2017 and the matched RSEM upper-quartile normalized tumour RNA matrix. The two HPA antibody series and normal-colon context are listed in the ancillary audit. Image-based or patient-matched TMEM87A tumour–normal quantification is unavailable in that audit.
