# Ancillary HPA evidence audit

Records accessed 16 October 2026. These observations summarize public annotations; no new IHC experiment, image-selected score or outcome model was performed.

| Target and resource | Observed record | Interpretation and limit |
|---|---|---|
| TMEM87A colorectal cancer, HPA018104 | High 9/10; medium 1/10; cytoplasmic/membranous 10/10; >75% stained 10/10 | Supports protein presence; does not establish tumour specificity or quantitative tumour-normal difference |
| TMEM87A colorectal cancer, HPA018189 | High 9/11; medium 2/11; cytoplasmic/membranous 11/11; >75% stained 11/11 | Separate antibody summary; sample overlap unresolved, so do not add denominators |
| TMEM87A normal colon | Glandular cells high for both antibodies | Normal glandular expression prevents a tumour-exclusive claim |
| TMEM87A assay validation | IHC enhanced through independent-antibody agreement; WB uncertain | Validation is assay-specific; no inference of a validated Western-blot band |
| TMEM63A colorectal cancer | Cancer tissue analysis pending | Unavailable IHC evidence, not negative staining |
| TMEM63A antibody panel | HPA066504, HPA066936, HPA068918: enhanced ICC independent-antibody agreement; IHC N/A | Cell-line ICC cannot substitute for CRC tissue IHC |
| HPA CPTAC display | 197 samples in the colon cancer proteomic display | Same underlying CPTAC resource family; not counted as another independent validation cohort |

Exact source pages:

- [TMEM87A colorectal cancer](https://www.proteinatlas.org/ENSG00000103978-TMEM87A/cancer/colorectal%2Bcancer)
- [TMEM87A normal colon](https://www.proteinatlas.org/ENSG00000103978-TMEM87A/tissue/colon)
- [TMEM87A antibody validation](https://www.proteinatlas.org/ENSG00000103978-TMEM87A/summary/antibody)
- [TMEM63A colorectal cancer](https://www.proteinatlas.org/ENSG00000196187-TMEM63A/cancer/colorectal%2Bcancer)
- [TMEM63A antibody validation](https://www.proteinatlas.org/ENSG00000196187-TMEM63A/summary/antibody)

No HPA patient images were selected for a case-control comparison. Figure 4 uses the actual H&E context supplied with GSE280315, not HPA IHC. H&E morphology does not measure either target protein. Reuse of HPA pathology images would require image-specific attribution, terms review and a prespecified sampling/scoring design.
