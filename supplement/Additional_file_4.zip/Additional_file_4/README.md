# Additional file 4 · External colorectal proteomics

## Laser-microdissection analysis

[PXD002137](https://proteomecentral.proteomexchange.org/cgi/GetDataset?ID=PXD002137-3) includes the MaxQuant search output for the [original colorectal proteomic study](https://doi.org/10.1021/acs.jproteome.5b00523). Eight same-patient carcinoma and adjacent normal-appearing mucosa pairs were identified from the depositor's experimental design and the common case numbers of the C/N experiments. The archive also contains 16 adenomas outside this comparison. We matched exact gene symbols and reference accessions after filtering reverse, contaminant and site-only groups. The total distinct peptide counts for TMEM87A (Q8NBN3) and TMEM63A (O94886) were 12 and 14, respectively, at the protein-group level. Protein-group identification does not assign abundance to individual cells or resolve proteoforms.

`lcm_pairs.tsv` contains both measured LFQ intensities for each pair. For strictly positive intensities, the tumour-to-reference ratio was log₂-transformed before averaging across patients. An unquantified intensity contributes no log-ratio. `lcm_estimates.tsv` gives complete-pair counts, mean, median, geometric mean ratio, t-based 95% intervals and two-sided exact sign-flip P values. The primary two-target comparison uses Benjamini–Hochberg adjustment. Same-cohort estimates for EPCAM, KRT18, PTPRC and COL1A1 provide exploratory context. No correction across the context markers is reported. Case 10 was excluded in the acquisition-date sensitivity analysis because its first carcinoma and mucosa raw files had different dates. The pair design table retains the raw-file metadata.

## Pathology-guided regional comparison

The [FAXP study](https://doi.org/10.1038/s41467-024-53683-7) deposited DIA protein groups, batch design and discovery DDA information in [PXD041412](https://proteomecentral.proteomexchange.org/cgi/GetDataset?ID=PXD041412). The file called `20230404_FAXP_CRC_Batch_design.tsv` is an OOXML workbook. Six pooled reference runs were outside the regional analysis. One designed run (`b1_1`) had no matrix column. Of three patients with carcinoma punches, two also had normal-region punches. The comparison uses carcinoma regions, combining central and peripheral carcinoma where applicable, and normal regions. Dysplasia samples were excluded from that contrast.

Within a section we subtracted the median log₂ intensity for normal-region punches from the median for carcinoma punches, using quantified positive values. The patient summary gives equal weight to the patient's eligible sections. Coverage tables retain observations without a positive intensity. The same-batch tables use only comparable section and batch strata. The DDA table provides complementary identification from the deposited FragPipe results. The unit of biological replication is the patient. The four matched sections represent two patients. Each punch measures a mixed tissue region.

For TMEM87A the patient differences were −0.062 for P1 and −0.285 for P3 (log₂ units). Quantification was available for 40 of 41 carcinoma punches and 23 of 26 normal-region punches in those patients. TMEM63A differences were +0.890 and +0.570, respectively, with complete quantification. Both patients are reported individually.

## Verify the results

With Python 3.12, pandas and SciPy installed, extract this ZIP and run in its folder:

```console
python verify_proteomics.py
```

This checks the ZIP member hashes and regenerates the LCM point estimates, t intervals, sign-flip P values, two-target q values and FAXP patient-level means from the bundled derived observations. To start from the original deposits instead, consult the stable URLs, file sizes and SHA-256 values in `input_manifest.tsv`. The table-extraction scripts accept source and output paths:

```console
python reanalyze_lcm.py /path/to/PXD002137/search.zip reproduced
python reanalyze_faxp.py /path/to/PXD041412 reproduced
```

These scripts read the deposited search and quantification outputs. They reproduce the reported secondary analyses at that starting point.
