# Epithelial RNA detection and abundance among detected cells

Each row in `patient_components.tsv` describes one gene in one patient with at least 20 epithelial cells in each tissue class. Both fixed genes are retained. In GSE132465 and GSE178341 we use all preparations. In GSE166555 we pool cells from repeat specimens within each patient and tissue class. Detection is the fraction of cells with a strictly positive measured value. All cells enter the overall mean. The quantities labelled `mean_detected` are the arithmetic mean of the measured normalized values in the detected subset. Normalized measurements use the source scale for GSE132465 and CP10K for the two UMI cohorts.

The columns `total`, `detection` and `detected_cell_mean` are within-patient log₂ ratios of tumour to adjacent tissue. Before rounding, the first equals the sum of the other two. A detection fraction of zero makes the paired decomposition undefined. All 110 patient–gene comparisons met the positivity criterion. The conditional mean measures signal within an assay-selected subset of cells.

`cohort_components.tsv` reports equal-patient averages, eligible and defined counts, and marginal 95% percentile bootstrap intervals from 5,000 draws per cohort and gene. The random seed is 20261125. Intervals for component estimates cannot be added. The original analysis of all-cell means used a different bootstrap stream, so interval endpoints can differ slightly. This post hoc description uses the same patients as the main analyses. No additional hypothesis tests were applied.

With Python, NumPy and pandas installed, extract this file and run the following command. Supply the directory containing `Additional_file_1.zip` and `Additional_file_2.zip` as the first argument.

```console
python decompose_expression.py /path/to/supplements /path/to/output
```

The script verifies the log-ratio identity for each patient and checks the external cohort's group sizes, mean expression, detection fraction and conditional mean against the cell-level values in Additional file 2. It regenerates both TSV files.
