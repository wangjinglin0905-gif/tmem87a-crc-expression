# Additional file 3 Spatial results and reproduction

## Source files and geometry

`spatial_*` files provide coverage, author label mapping and summaries for GSE280315 8-µm Visium HD bins. Input hashes refer to the author deposited file set. Three source overviews used for Figure 4 are sampled and displayed at reduced resolution. The underlying histological image files are [GSM8594567 P1CRC](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM8594567), [GSM8594568 P2CRC](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM8594568) and [GSM8594569 P5CRC](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM8594569). P2 was also released by 10x Genomics with CC BY 4.0 terms. The geometric checks pertain to the GEO-deposited BTF overview and the original full-resolution mapping. `hd_image_geometry.json` and the donor-specific records describe alignment and display boundaries. The four Figure 5 H&E image sources correspond to GSM7089855–58 in [GSE226997](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE226997) through [the pinned STimage release](https://huggingface.co/datasets/jiawennnn/STimage-1K4M/tree/b2073c6e8bb7e6d8dfd15c0db6134ba4f2a8a84f). These archives contain image provenance and derived tables.

`GSE226997_*` tables record four unpooled sections, the gene set used to score regions, target effects and counts. `depth_overlap_diagnostics.tsv` retains the full post hoc depth checks, `depth_coverage_audit.tsv` provides retained proportions and documented amendments describe how the diagnosis arose and how missing KRT19 coverage was handled.

## Rebuild selected results

Extract the three numbered ZIPs into the same directory. With Python 3.12, NumPy 2.4.6, pandas 2.3.3, SciPy 1.18.0 and Matplotlib available, run from that directory:

```console
python Additional_file_3/reproduce.py --data . --output reproduced
```

This checks GSE166555 primary paired means, detection and raw-scale contrasts with Wilcoxon and two-target BH, the CPTAC paired means and Spearman correlations, the full and trimmed conventional Visium point estimates, and the depth-overlap counts and estimates in the cell and spot cohorts. It regenerates a stand-alone statistical plot of the two Figure 5 contrasts and machine-readable checks. Input `sha256.json` files list the members of each archive. The reproduction starts at the bundled derived data. Original-matrix extraction, Cox refitting, original microscope-image rendering and bootstrap interval recalculation remain covered by the historical source records and are outside this command.
